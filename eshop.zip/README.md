# svab.maturita.projekt
 **NÁVOD K POUŽITÍ**
 1. V datovém modelu vytvořte schéma(eshop), všechny tabulky(users, products, orders, order_items, cart), insertněte admina a produkty a vytvořte view (admin_panel)
 2. Už na webu klikněte v navigačním menu na přihlásit se. Buď se přihlásíte jako admin (adam.dl@seznam.cz heslo: 12345) a nebo se zaregistrujete
 3. Po té co jste přihlášen můžete začit nakupovat.
 4. Kliknete na Přidat do košíku a produkt se přidá do košíku
 5. Když se dostanete do košíku můžete buď měnit množství produktu( nastavením libovolné nezáporné hodnoty a stisknutim zelených šipek v kolečku) nebo ho smazat (červeným košem)
 6. Po stisknutí tlačÍtka odstranit košÍk, se smažou všechny produkty z košíku.
 7. Když kliknete na tlačitko pokladna přesměruje vás to na na doručovací údaje a potvrzení objednávky.
 8. Následným potvrdit vás web přesměruje na souhrn vaší objednávky.
 9. Když kliknete na v navigačním menu na Můj účet ukaží se vám údaje o vašem profilu a tlačítko pro odhlášení.

- ADMIN MÁ V MŮJ ÚČET TLAČÍTKO NAVÍC (ADMIN_PANEL) KDE VIDÍ SEZNAM VŠECH OBJEDNÁVEK
- PO STISKNUTÍ ČERVENÉHO TLAČÍTKA NA KONCI ŘÁDKU SE UKÁŽE DETAIL DANNÉ OBJEDENÁVKY S TLAČÍTKEM KTERÁ UMOŽŇUJE ZMĚNU STAVU OBJEDNÁVKY NA (ODESLÁNO)


